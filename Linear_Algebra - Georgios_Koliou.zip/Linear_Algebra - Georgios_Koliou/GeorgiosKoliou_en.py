#!/usr/bin/env python
# coding: utf-8

# <center><i><img src="https://www.python.org/static/apple-touch-icon-72x72-precomposed.png"></i></center>

# # <center>Linear Algebra Fundamentals in Python from <i><font color="blue">Koliou Georgios</font></i></center>

# ## <h2>The script calculates:<br><br><ul><li><a href="https://en.wikipedia.org/wiki/LU_decomposition">Determinant.</a></li><br><li><a href="https://en.wikipedia.org/wiki/Trace_(linear_algebra)">Trace of a Matrix.</a></li><br><li><a href="https://en.wikipedia.org/wiki/Transpose">Transpose.</a></li><br><li><a href="https://en.wikipedia.org/wiki/Invertible_matrix">Invertible Matrix.</a></li><br><li><a href="https://en.wikipedia.org/wiki/Rank_(linear_algebra)">Rank.</a></li></ul></h2>

# In[ ]:


#from termcolor import colored
#print(colored('Author:', 'red'), colored('Georgios Koliou', 'green'), colored("Contact:","red"), colored('georgios.koliou@gmail.com\n\n', 'green'))
print("Author: Georgios Koliou\nContact: georgios.koliou@gmail.com\n\n")


# In[ ]:


# The library used for this purpose, Numpy
import numpy as np


# ## How to insert any matrix of any size.

# In[ ]:


# Rows x Columns
R = int(input("Give number of rows: "))
C = int(input("\nGive number of columns: "))


# In[ ]:


# The user enters all the numbers of the matrix from the keyboard.
print("\nInsert all the elements:\n ")
num = list(map(int, input().split()))


# In[ ]:


matrix = np.array(num).reshape(R, C)
if R==C:
    print("\nThe inserted matrix is square and is the following:\n\n",matrix,)
else:
    print("\nThe inserted matrix has dimensions (",R,"x",C,") and is the following:\n\n",matrix,)


# ## <i><font color="#737373">Determinant</font></i>

# In[ ]:


# This method calculates the determinant with LU factorization
# The determinant is calculated only for square matrices
# If rows == columns det is calculated, otherwise no
if R==C:
    det = np.linalg.det(matrix)
    print("\nThe Determinant is equal: "'{0:.0f}'.format(det))
else:
    print("\nThe Determinant is equal: The matrix is not square!")


# ## <i><font color="#737373">Trace</font></i>

# In[ ]:


# If inserted matrix is not square, trace is not calculated
if R==C:
    tr = np.trace(matrix)
    print("\nTrace is equals: ",tr,)
else:
    print("\nTrace is equal: The matrix is not square!")


# ## <i><font color="#737373">Transpose</font></i>

# In[ ]:


trasp = matrix.transpose()
print("\nThe Transpose of the matrix is equal:\n\n",trasp,)


# ## <i><font color="#737373">Invertible Matrix</font></i> A<sup>-1</sup>.

# In[ ]:


# A matrix is invertible if its determinant is different from 0, otherwise no.
if R==C and det != 0:
    from numpy.linalg import inv
    inverse = inv(matrix)
    print("\nDeterminant equal ",'{0:.0f}'.format(det),"!=0, therefore the matrix is invertible and its inverse is equal:\n\n",inverse,)
    #print(colored("\nDeterminant equal ",'{0:.0f}'.format(det),"!=0, therefore the matrix is invertible and its inverse is equal:\n\n",'red'))
    #print(inverse)
    matver = np.matmul(matrix, inverse)    # VERIFICATION. A*A^-1 = I
    print("\nVERIFICATION: Must be printed identity matrix (",R,"x",C,").\n\n",matver,)
       
elif R != C:
    print("\nThe matrix is not invertible because: It is not square, has",R,"rows and",C,"columns\n")
    
else:
    print("\nThe matrix is not invertible because its determinant is equal to 0.")


# In[ ]:


x = np.identity(R)
#diag = np.diag(matrice)
if matver.any == x.any:
    print('True')
else:
    print('False')


# In[ ]:


np.identity(R)


# ## <i><font color="#737373">Rank</font></i>

# In[ ]:


# Rank is equals with number of rows linearly independent
from numpy.linalg import matrix_rank
rk = matrix_rank(matrix) 
print("\nRank is equals to: ",rk,)


# In[ ]:


input('\n\n\nPress ENTER to exit')


# <p><a target="_blank" rel="noopener noreferrer" href="https://www.youtube.com/channel/UCFGQd5PSirHFeZxvOpSLxkQ" title="YouTube"><i><img src="https://www.youtube.com/yts/img/favicon_32-vflOogEID.png"></i></a></p>
